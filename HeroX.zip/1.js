function contactWhatsApp(productName) {
    const whatsappNumber = '+905550066123'; // غير هذا إلى رقمك الحقيقي
    const message = `مرحباً، أريد طلب: ${productName}.`;
    const whatsappUrl = `https://wa.me/${whatsappNumber}?text=${encodeURIComponent(message)}`;
    window.open(whatsappUrl, '_blank');
}


function searchProducts() {
    const query = document.getElementById('search-input').value.toLowerCase().trim();
    const sections = document.querySelectorAll('.products');
    sections.forEach(section => {
        const sectionTitle = section.querySelector('h2').textContent.toLowerCase();
        if (sectionTitle.includes(query) || query === '') {
            section.style.display = 'block';
        } else {
            section.style.display = 'none';
        }
    });
}

// تأثير fade-in عند التمرير
const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.classList.add('visible');
        }
    });
}, { threshold: 0.1 });

document.querySelectorAll('.fade-in').forEach(section => {
    observer.observe(section);
});